<?php
include '_config.php';

$username = $_POST['username'];
$password = $_POST['password'];



$query = "SELECT * FROM user WHERE username = '$username' AND password = '$password' ";
$result = mysqli_query($con, $query);
$row = mysqli_fetch_array($result);


if ($row > 0) { // Start a new session
  session_start();
  $_SESSION['login_user']= $username; 
  
  ?>


    <script>
        alert('Berhasil Login!')
        location.href = 'index.php'
    </script>
<?php
} else { ?>
    <script>
        alert('Gagal Login! User tidak terdaftar')
        location.href = 'login.php'
    </script>
<?php } ?>