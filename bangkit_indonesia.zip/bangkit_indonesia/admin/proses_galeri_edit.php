<?php session_start(); if( $_SESSION['login_user'] == null){header('location:login.php');   }?>
<?php
error_reporting(0);
include '_config.php';

$gambar = $_POST['gambar'];
$user = $_POST['id'];
$id_user = $_POST['user'];

$keterangan = $_POST['keterangan'];
$data = mysqli_query($con, "SELECT * FROM gallery WHERE id=11");
$row = mysqli_fetch_array($data);


//upload dan simpan artikel
$namafile = $_FILES['gambar']['name'];
$tmp_name = $_FILES['gambar']['tmp_name'];
move_uploaded_file($tmp_name, 'img_gallery/' .  $namafile);

if ($namafile == '') {
    $update = mysqli_query($con, "UPDATE gallery SET keterangan='$_POST[keterangan]', id_user = '$id_user' WHERE id ='$_POST[id]'");
} else {
    $update = mysqli_query($con, "UPDATE gallery SET gambar='$namafile', keterangan='$_POST[keterangan]', id_user = '$id_user'  WHERE id ='$_POST[id]'");
}
if ($update) { ?>
<script>
alert('Data berhasil diubah!')
location.href = 'galeri.php'
</script>
<?php
} else { ?>
<script>
alert('Data Gagal diubah!')
location.href = 'galeri.php'
</script>
<?php } ?>