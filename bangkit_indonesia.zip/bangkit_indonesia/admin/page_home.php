
<div class="card im-box">
<h5 class="card-header">Selamat Datang di Website Kelompok 1</h5>
<div class="card-body">
<h5 class="card-title">Halo Semua Teman Mahasiswa MBKM PMM - PKBN Bela Negara!</h5>
<p class="card-text">Kami dari Kelompok 1 sebagai
generasi muda tidak boleh berhenti berkreasi, berinovasi, dan berprestasi. Kita harus membuktikan
kemahiran kita, kekuatan kita, dan ketangguhan kita. Kita harus meraih masa depan kita 
dan mewujudkan cita-cita para Pendiri Bangsa dengan Semangat Bela 
Negara salah satunya melalui Program MBKM PMM - PKBN.</p> 

<h5 class="card-title">Kelompok 1 :</h5>
<table>
<th>
        <tr>
            <th rowspan="1">Nama</th>
            <th colspan="2">Nim</th>
        </tr>
</th>
        <tr>
            <td> Eko Fani Setiawan </td>
            <td> 77222326</td>
        </tr>
        <tr>
            <td>Siti Sarah Humairah</td>
            <td>77222286</td>
        </tr>
        <tr>
            <td>Srikarmila Nurul Fatima</td>
            <td>77222304</td>
        </tr>
        <tr>
            <td>Muhammad Rizky Ramdhani</td>
            <td>77222314</td>
        </tr>
        <tr>
            <td>Ranti Oriza Savitri</td>
            <td>77222285</td>
        </tr>
        <tr>
            <td>Zidan Febryan</td>
            <td>77222297</td>
        </tr>
        <tr>
            <td>Muhammad Rizky</td>
            <td>77222303</td>
        </tr>
        <tr>
            <td>Muhammad Fadlan Putra Pratama</td>
            <td>77222278</td>
        </tr>
        <tr>
            <td>Muhammad Prasetyo</td>
            <td>77222302</td>
        </tr>
        <tr>
            <td>Rere Setiawan</td>
            <td>77222283</td>
        </tr>
    </table>

</div>
</div>