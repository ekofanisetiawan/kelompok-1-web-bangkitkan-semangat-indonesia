<?php session_start(); if( $_SESSION['login_user'] == null){header('location:login.php');   }?>
<?php
include '_config.php';
$id = $_GET['id'];
$delete = mysqli_query($con, "DELETE FROM user WHERE id_user = $id");
if ($delete) { ?>
<script>
alert('Data berhasil dihapus!')
location.href = 'page_user.php'
</script>
<?php
} else { ?>
    <script>
        alert('Data Gagal dihapus!')
        location.href = 'page_user.php'
    </script>
<?php } ?>