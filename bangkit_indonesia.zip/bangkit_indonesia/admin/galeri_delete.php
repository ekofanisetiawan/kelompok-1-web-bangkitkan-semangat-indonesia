<?php session_start(); if( $_SESSION['login_user'] == null){header('location:login.php');   }?>
<?php
include '_config.php';

$id = $_GET['id'];

$delete = mysqli_query($con, "DELETE FROM gallery WHERE id = $id");

if ($delete) { ?>
    <script>
        alert('Data berhasil dihapus!')
        location.href = 'galeri.php'
    </script>
<?php
} else { ?>
    <script>
        alert('Data Gagal dihapus!')
        location.href = 'galeri.php'
    </script>
<?php } ?>