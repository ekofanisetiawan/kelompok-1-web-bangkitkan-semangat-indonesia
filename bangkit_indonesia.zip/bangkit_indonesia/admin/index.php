<?php session_start(); if( $_SESSION['login_user'] == null){header('location:login.php');   }?>
<?php include '_header.php'; ?>
<!-- content -->
<div class="container mt-5">    
<?php include 'page_home.php'; ?>
</div>
<!-- ./content -->
<?php include '_footer.php'; ?>